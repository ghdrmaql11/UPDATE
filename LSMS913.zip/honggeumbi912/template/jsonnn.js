
var obj=[];
String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}
var sd;
var str="{'NO':'1','NAME':'APPLE','KOR':'사과','PRICE':'1000'},{'NO':'2','NAME':'BANANA','KOR':'바나나','PRICE':'500'},{'NO':'3','NAME':'MELON','KOR':'메론','PRICE':'2000'}";
str = str.replaceAll("},", "}|");

var array = str.split("|");



for (var i=0; i<array.length; i++)

{
    console.log(i)
    // console.log("sd"+array[i])
    // obj[i]= eval(array[i]);
    //sd=array[i];
    // obj.add(eval(sd));
    obj[i] = eval("("+array[i]+")");


}
console.log("asdsa"+obj)